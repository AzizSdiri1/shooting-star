# Pygame template
import pygame
import random 
import os
import winsound  

WIDTH = 1300
HEIGHT = 700
FPS = 60 #3adad ella9tat fi thenya //a7sen 7aja 

# define colors
asfar = (255, 165, 0)
WHITE = (255, 255, 255) #class heya chnoowa bech n7otoo 
BLACK = (0, 0, 0)
RED1 = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
pink=(255,105,180)
RED=(125,0,0)
counter=0
# initialize pygame and create window
class zizoo(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self) #bech yasne3 el sprite
        self.image=joueur
        self.image=pygame.transform.scale(self.image,(90 ,50 ))
        self.image.set_colorkey(BLACK) #bech nfasa5 Background
        self.rect=self.image.get_rect()#ya3ml mooraba3 deyer bel taswira
        self.rect.center=(100,HEIGHT/2)
        self.vol=0
        self.Herz=3
        
    def update(self):
        self.vol=0 
        nazla=pygame.key.get_pressed()
        
        if nazla[pygame.K_DOWN]:
            self.vol=5
        if nazla[pygame.K_UP]:
            self.vol=-5
        if self.rect.top<0 :
            self.rect.y+=5
        if  self.rect.bottom>HEIGHT :
            self.rect.y-=5
        else :
            self.rect.y+=self.vol
        # tzid 5 pixel fi kol fps *fil frame 
    def shooting(self):
         shot=rsasa(self.rect.x+50,self.rect.y+25)
         all_sprites.add(shot)
         rsasat.add(shot)
class mob(pygame.sprite.Sprite):
    def __init__(self,x):
        pygame.sprite.Sprite.__init__(self) #bech yasne3 el sprite
        self.image=en
        self.image.set_colorkey(BLACK)
        self.rect=self.image.get_rect()#ya3ml mooraba3 deyer bel taswira
        self.rect.center=(WIDTH,random.randrange(20,650))
        self.vol=random.randrange(2,5)+x
         
    def update(self):
        if self.rect.left<0 :
            self.rect.x=random.randrange(WIDTH,WIDTH+20)#7abithom yjoo men blayes mo5talfa mech jeyin kol men nafes leblasa
            
            self.rect.y=random.randrange(20,650)
            self.vol=random.randrange(3,9)+x
        else :
            self.rect.x-=self.vol
class rsasa(pygame.sprite.Sprite):
    def __init__(self,x,y):
        pygame.sprite.Sprite.__init__(self) 
        self.image=pygame.Surface((20,5))
        self.image.fill(asfar)
        self.rect=self.image.get_rect()
        self.rect.center=(x,y)
        self.vol=40
    def update(self):
        self.rect.x+=self.vol
        
    
pygame.init()#ma3endhom 7ata ma3na
pygame.mixer.init()#ma3endhom 7ata ma3na 
screen = pygame.display.set_mode((WIDTH, HEIGHT))#akaka tetktab
pygame.display.set_caption("Shooting Star") #display heya lecran
clock = pygame.time.Clock() #just bech nejem ne5dem bel fps


game=os.path.dirname(__file__)#lazma
image=os.path.join(game,"img")#
joueur=pygame.image.load(os.path.join(image,"1.png")).convert()
bg=pygame.image.load(os.path.join(image,"2.png")).convert()
bg=pygame.transform.scale(bg,(1300,700))
en=pygame.image.load(os.path.join(image,"3.png")).convert()
en=pygame.transform.scale(en,(70,50 ))
hzin=pygame.image.load(os.path.join(image,"5.png")).convert()
hzin=pygame.transform.scale(hzin,(50,44 ))
hzin.set_colorkey(BLACK)
beg=pygame.image.load(os.path.join(image,"6.jpg")).convert()
beg=pygame.transform.scale(beg,(1300,700))
ov=pygame.image.load(os.path.join(image,"7.jpg")).convert()
ov=pygame.transform.scale(ov,(1300,700))
tr=pygame.image.load(os.path.join(image,"6.png")).convert()
tr=pygame.transform.scale(tr,(1300,700))
tab=[]

for i in range(3):
    ardh=pygame.image.load(os.path.join(image,"4.png")).convert()
    ardh=pygame.transform.scale(ardh,(50,44 ))
    ardh.set_colorkey(BLACK)
    tab.append(ardh) #7otha fi a5er liste ma3naha 

all_sprites = pygame.sprite.Group() # tnajem ta3ml zooz w ella tlatha ...
mobs= pygame.sprite.Group() #aka dabebet 
rsasat=pygame.sprite.Group()#mta3 rsasat 
run=True
aziz=zizoo() 
all_sprites.add(aziz)
n=1
x=0
Begin=True
colorb=asfar
colora=WHITE
while Begin:
    for i in pygame.event.get():
                # check for closing window
        if i.type == pygame.QUIT:
            Begin = False
            run= False
        if i.type==pygame.KEYDOWN :
            if i.key == pygame.K_SPACE:
                Begin=False #bech to5roj mel begin
            if i.key == pygame.K_DOWN or i.key == pygame.K_UP :
                aus=colora
                colora=colorb
                colorb=aus
                run=not run
                
    font = pygame.font.SysFont('OCR A EXTENDED', 60)
    screen.blit(beg,(0,0))
    r_img = font.render("START", True, colorb)
    screen.blit(r_img, ((500, 220 )))#positionnn 
    r_img = font.render("QUIT", True, colora)
    screen.blit(r_img, ((500, 320 )))#positionnn mta3 lpoint
    font = pygame.font.SysFont('OCR A EXTENDED', 20)
    r_img = font.render("by Aroua Sdiri", True, RED1)
    screen.blit(r_img, ((1070, 650 )))
    pygame.display.update()
while run:
    transition=True
    
     #5aterha class mech variable
    for i in range(10):
        
        moob=mob(x)
        mobs.add(moob)
        all_sprites.add(moob)
    # Game loop
    running = True #bech tabh9a dour dour 
    while running:
        # keep loop running at the right speed
        clock.tick(FPS) # just bech t5allaha temchio b 30 FPS fi thenya 
        # Process input (events)
        for i in pygame.event.get():
            # check for closing window
            if i.type == pygame.QUIT:
                running = False
                run=False
                transition=False
                over=False
            if i.type==pygame.KEYDOWN :
                if i.key == pygame.K_SPACE:
                    aziz.shooting()
                    winsound.PlaySound('a.wav',winsound.SND_ASYNC) 
                    
        dharba=pygame.sprite.spritecollide(aziz,mobs,True)
        if dharba:
            
            aziz.Herz-=1
            tab[aziz.Herz]=hzin
            if aziz.Herz==0:
                running=False
                run= False
                transition=False
                over=True
        massa=pygame.sprite.groupcollide(rsasat,mobs,True,True)
        if massa:
            counter+=random.randrange(40,80 )
            
        if len(mobs)==0:
            running=False
            over=False
            x+=2
            n+=1
        # Update
        all_sprites.update()
        
        # Draw / render
        font = pygame.font.SysFont('OCR A EXTENDED', 30)#'el 5at w kober el 5at '
        screen.blit(bg,(0,0))
        r_img = font.render("Score:"+str(counter), True, pink)
        screen.blit(r_img, ((1070, 650 )))
        screen.blit(tab[0],((930,650)))
        screen.blit(tab[1],((870,650)))
        screen.blit(tab[2],((810,650)))
        all_sprites.draw(screen) 
        # after drawing everything, flip the display
        pygame.display.update() # mise a jour
    
    screen.fill(BLACK)
    while transition:
        for i in pygame.event.get():
            # check for closing window
            if i.type == pygame.QUIT:
                transition = False
                run=False
            if i.type==pygame.KEYDOWN :
                if i.key == pygame.K_SPACE:
                    transition=False  
        font = pygame.font.SysFont('OCR A EXTENDED', 60)
        screen.blit(tr,(0,0))
        r_img = font.render("Click Space to continue", True, RED)
        screen.blit(r_img, ((250, 150 )))
        r_img = font.render("Level "+str(n), True, RED)
        screen.blit(r_img, ((500, 250 )))  
        pygame.display.update()
    screen.fill(RED)
    while over:
        for i in pygame.event.get():
            # check for closing window
            if i.type == pygame.QUIT:
                over = False
                run=False
        font = pygame.font.SysFont('OCR A EXTENDED', 60)
        screen.blit(ov,(0,0))
        r_img = font.render("GameOver", True, RED1)
        screen.blit(r_img, ((250, 250 )))
        r_img = font.render("Score "+str(counter), True, WHITE)
        screen.blit(r_img, ((500, 320 )))  
        pygame.display.update()


    
pygame.quit()
